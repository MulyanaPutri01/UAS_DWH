<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="float-start">
            <p>2021 &copy; SPK - SAW Method</p>
        </div>
        <div class="float-end">
            <p> <span class="text-danger"><i class="bi bi-heart"></i></span> by <a>Mulyana Putriyani - 19090113</a></p>
        </div>
    </div>
</footer>
